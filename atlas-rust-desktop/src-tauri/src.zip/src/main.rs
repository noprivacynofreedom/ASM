#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
mod process_supervisor;
mod telemetry;
mod evidence;
mod atlas_node;

use serde::Serialize;
use tokio::sync::Mutex;
use tauri::{Manager, State};
use std::{path::PathBuf, sync::{Arc, atomic::{AtomicBool, Ordering}}};

#[derive(Default)]
struct RuntimeState { children: Mutex<process_supervisor::OwnedChildren>, shutdown_started: AtomicBool, shutdown_complete: AtomicBool }
struct NodeState { manager: Arc<atlas_node::NodeManager> }
impl NodeState { fn new() -> Self { let root = std::env::var_os("LOCALAPPDATA").map(PathBuf::from).map(|p| p.join("Atlas").join("Node")).or_else(|| std::env::var_os("XDG_DATA_HOME").map(PathBuf::from).or_else(|| std::env::var_os("HOME").map(PathBuf::from).map(|p| p.join(".local").join("share"))).map(|p| p.join("Atlas").join("Node"))).unwrap_or_else(|| PathBuf::from("atlas-node-data")); Self { manager: Arc::new(atlas_node::NodeManager::new(root)) } } }
#[derive(Serialize)]
struct Health { atlas_api: bool, llama_swap: bool, atlas_api_detail: String, llama_detail: String }

#[tauri::command]
async fn health_check() -> Health {
    let client = reqwest::Client::builder().timeout(std::time::Duration::from_secs(2)).build().unwrap();
    let atlas = client.get("http://127.0.0.1:8090/api/health").send().await;
    let swap = client.get("http://127.0.0.1:8080/v1/models").send().await;
    Health {
        atlas_api: atlas.as_ref().is_ok_and(|r| r.status().is_success()),
        llama_swap: swap.as_ref().is_ok_and(|r| r.status().is_success()),
        atlas_api_detail: atlas.map(|r| format!("HTTP {}", r.status())).unwrap_or_else(|e| e.to_string()),
        llama_detail: swap.map(|r| format!("HTTP {}", r.status())).unwrap_or_else(|e| e.to_string()),
    }
}
#[tauri::command]
fn system_metrics() -> telemetry::SystemMetrics { telemetry::snapshot() }

#[tauri::command]
async fn local_ops_snapshot() -> Result<serde_json::Value, String> {
    let client = reqwest::Client::builder().timeout(std::time::Duration::from_secs(3)).build().map_err(|e| e.to_string())?;
    let state = client.get("http://127.0.0.1:8090/api/state").send().await.map_err(|e| format!("Atlas state API unavailable: {e}"))?;
    if !state.status().is_success() { return Err(format!("Atlas state API returned HTTP {}", state.status())); }
    let app_state = state.json::<serde_json::Value>().await.map_err(|e| format!("Atlas state JSON invalid: {e}"))?;
    let audit = client.get("http://127.0.0.1:8090/api/mcp/audit").send().await;
    let mcp_events = match audit { Ok(r) if r.status().is_success() => r.json::<serde_json::Value>().await.unwrap_or_else(|_| serde_json::json!({"events":[]})), _ => serde_json::json!({"events":[]}) };
    Ok(serde_json::json!({"state":app_state,"mcp_audit":mcp_events,"captured_at_unix":std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap_or_default().as_secs()}))
}
#[tauri::command]
async fn start_legacy_services(state: State<'_, RuntimeState>) -> Result<String, String> {
    if state.shutdown_started.load(Ordering::Acquire) {
        return Err("Atlas is shutting down; refusing to start new services".into());
    }
    let mut guard = state.children.lock().await;
    if state.shutdown_started.load(Ordering::Acquire) {
        return Err("Atlas is shutting down; refusing to start new services".into());
    }
    guard.start().await
}
#[tauri::command]
async fn stop_owned_services(state: State<'_, RuntimeState>) -> Result<String, String> {
    let mut guard = state.children.lock().await;
    guard.stop();
    Ok("Stopped only Atlas-owned child processes.".into())
}
#[tauri::command]
fn record_tool_result(tool: String, ok: bool, summary: String) -> evidence::EvidenceRecord {
    evidence::record_execution(&tool, ok, &summary)
}


#[tauri::command]
fn node_status(state: State<'_, NodeState>) -> Result<atlas_node::NodeStatus, String> { state.manager.status() }
#[tauri::command]
fn node_config_view(state: State<'_, NodeState>) -> Result<atlas_node::NodeConfigView, String> { state.manager.config_view() }
#[tauri::command]
fn node_identity(state: State<'_, NodeState>) -> Result<serde_json::Value, String> { state.manager.public_identity() }
#[tauri::command]
fn node_set_enabled(enabled: bool, state: State<'_, NodeState>) -> Result<atlas_node::NodeStatus, String> { state.manager.set_enabled(enabled) }
#[tauri::command]
fn node_update_policy(allow_remote_workloads: bool, allow_networked_inference: bool, max_cpu_percent: u8, max_memory_mb: u64, state: State<'_, NodeState>) -> Result<atlas_node::NodeStatus, String> { state.manager.update_policy(allow_remote_workloads, allow_networked_inference, max_cpu_percent, max_memory_mb) }
#[tauri::command]
fn node_configure(gateway_url: String, ollama_url: String, trusted_scheduler_key_hex: String, allowed_images: Vec<String>, state: State<'_, NodeState>) -> Result<atlas_node::NodeStatus, String> { let mut c=state.manager.config_for_ui()?; let next_gateway=gateway_url.trim_end_matches('/').to_string(); if c.gateway_url!=next_gateway { c.node_token.clear(); } c.gateway_url=next_gateway; c.ollama_url=ollama_url.trim_end_matches('/').to_string(); c.trusted_scheduler_key_hex=trusted_scheduler_key_hex.trim().to_string(); c.allowed_images=allowed_images.into_iter().map(|v|v.trim().to_string()).filter(|v|!v.is_empty()).collect(); state.manager.save_config(c)?; state.manager.status() }
#[tauri::command]
async fn node_register(state: State<'_, NodeState>) -> Result<serde_json::Value, String> { state.manager.register().await }
#[tauri::command]
async fn node_network_status(state: State<'_, NodeState>) -> Result<serde_json::Value, String> { state.manager.network_status().await }
#[tauri::command]
async fn node_submit_inference(model: String, prompt: String, max_tokens: u32, state: State<'_, NodeState>) -> Result<serde_json::Value, String> { state.manager.submit_inference(model,prompt,max_tokens).await }
#[tauri::command]
fn node_execute_workload(workload: atlas_node::WorkloadEnvelope, state: State<'_, NodeState>) -> Result<serde_json::Value, String> { state.manager.execute_signed_workload(workload) }
#[tauri::command]
fn node_contribution_ledger(state: State<'_, NodeState>) -> serde_json::Value { state.manager.ledger() }
#[tauri::command]
async fn node_local_models(state: State<'_, NodeState>) -> Result<serde_json::Value, String> { state.manager.local_models().await }
#[tauri::command]
async fn node_benchmark_local(model: String, prompt: String, state: State<'_, NodeState>) -> Result<serde_json::Value, String> { state.manager.benchmark_local(model,prompt).await }

fn main() {
    tauri::Builder::default()
        .manage(RuntimeState::default())
        .manage(NodeState::new())
        .setup(|app| { let manager = app.state::<NodeState>().manager.clone(); tauri::async_runtime::spawn(async move { manager.run_agent_loop().await; }); Ok(()) })
        .invoke_handler(tauri::generate_handler![health_check, system_metrics, local_ops_snapshot, start_legacy_services, stop_owned_services, record_tool_result, node_status, node_config_view, node_identity, node_set_enabled, node_update_policy, node_configure, node_register, node_network_status, node_submit_inference, node_execute_workload, node_contribution_ledger, node_local_models, node_benchmark_local])
        .build(tauri::generate_context!())
        .expect("error while building Atlas")
        .run(|app, event| {
            match event {
                tauri::RunEvent::ExitRequested { api, .. } => {
                    let runtime = app.state::<RuntimeState>();
                    // Prevent the first close request until the owned children have stopped.
                    // Once shutdown_complete is set, allow the programmatic exit through.
                    if !runtime.shutdown_complete.load(Ordering::Acquire) {
                        api.prevent_exit();
                    }
                    if !runtime.shutdown_complete.load(Ordering::Acquire) && runtime.shutdown_started.compare_exchange(false, true, Ordering::AcqRel, Ordering::Acquire).is_ok() {
                        let handle = app.clone();
                        tauri::async_runtime::spawn(async move {
                            handle.state::<NodeState>().manager.shutdown();
                            let state = handle.state::<RuntimeState>();
                            let mut children = state.children.lock().await;
                            children.stop();
                            drop(children);
                            state.shutdown_complete.store(true, Ordering::Release);
                            drop(state);
                            handle.exit(0);
                        });
                    }
                }
                tauri::RunEvent::Exit => {
                    // Last-resort exact-handle cleanup if the host forces process exit.
                    app.state::<NodeState>().manager.shutdown();
                    if let Ok(mut children) = app.state::<RuntimeState>().children.try_lock() { children.stop(); }
                }
                _ => {}
            }
        });
}
