use std::{
    fs::{File, OpenOptions},
    path::{Path, PathBuf},
    process::{Child, Command, Stdio},
    sync::{
        atomic::{AtomicBool, Ordering},
        Mutex,
    },
    time::Duration,
};

use serde_json::Value;
use tokio::{
    sync::Mutex as AsyncMutex,
    time::{sleep, Instant},
};

/// Owns only the exact child processes spawned by this Atlas desktop instance.
///
/// The child registry uses a short-lived std mutex so shutdown never needs to
/// `try_lock()` a Tokio mutex that may be held across an HTTP readiness wait.
/// Startup itself is serialized separately with an async mutex.
#[derive(Default)]
pub struct OwnedChildren {
    children: Mutex<Vec<Child>>,
    start_lock: AsyncMutex<()>,
    stop_requested: AtomicBool,
}

pub fn project_root() -> PathBuf {
    std::env::var_os("ATLAS_PROJECT_ROOT")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from(r"F:\APP-DEV\projects\atlas-chat"))
}

fn port_ready(port: u16) -> bool {
    let address = format!("127.0.0.1:{port}");
    address
        .parse()
        .ok()
        .and_then(|addr| {
            std::net::TcpStream::connect_timeout(&addr, Duration::from_millis(250)).ok()
        })
        .is_some()
}

fn ensure_not_stopping(stop_requested: &AtomicBool) -> Result<(), String> {
    if stop_requested.load(Ordering::Acquire) {
        Err("Atlas startup was cancelled because shutdown was requested.".into())
    } else {
        Ok(())
    }
}

async fn wait_http(
    url: &str,
    seconds: u64,
    stop_requested: &AtomicBool,
) -> Result<(), String> {
    let client = reqwest::Client::builder()
        .timeout(Duration::from_secs(2))
        .build()
        .map_err(|e| e.to_string())?;
    let until = Instant::now() + Duration::from_secs(seconds);

    loop {
        ensure_not_stopping(stop_requested)?;
        if let Ok(response) = client.get(url).send().await {
            if response.status().is_success() {
                return ensure_not_stopping(stop_requested);
            }
        }
        if Instant::now() >= until {
            return Err(format!("Service did not become ready: {url}"));
        }
        sleep(Duration::from_millis(300)).await;
    }
}

fn log_file(root: &Path, name: &str) -> Result<File, String> {
    std::fs::create_dir_all(root.join("logs")).map_err(|e| e.to_string())?;
    OpenOptions::new()
        .create(true)
        .append(true)
        .open(root.join("logs").join(name))
        .map_err(|e| e.to_string())
}


// Windows: prevent console-subsystem child processes from opening a visible console.
fn hide_console_window(command: &mut Command) {
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        const CREATE_NO_WINDOW: u32 = 0x0800_0000;
        command.creation_flags(CREATE_NO_WINDOW);
    }
}

fn spawn_python(root: &Path, script: &Path) -> Result<Child, String> {
    let stdout = log_file(root, "atlas-server.log")?;
    let stderr = stdout.try_clone().map_err(|e| e.to_string())?;
    let mut candidates: Vec<(&str, Vec<String>)> = vec![
        ("py", vec!["-3".into(), script.display().to_string()]),
        ("python", vec![script.display().to_string()]),
    ];
    #[cfg(not(windows))]
    {
        candidates = vec![
            ("python3", vec![script.display().to_string()]),
            ("python", vec![script.display().to_string()]),
        ];
    }

    let mut last = String::new();
    for (exe, args) in candidates {
        let mut command = Command::new(exe);
        command.args(args)
            .current_dir(root)
            .stdin(Stdio::null())
            .stdout(Stdio::from(stdout.try_clone().map_err(|e| e.to_string())?))
            .stderr(Stdio::from(stderr.try_clone().map_err(|e| e.to_string())?));
        hide_console_window(&mut command);
        match command.spawn() {
            Ok(child) => return Ok(child),
            Err(error) => last = format!("{exe}: {error}"),
        }
    }

    Err(format!(
        "Could not start Python server. Install Python 3 and ensure 'py' or 'python' is on PATH. {last}"
    ))
}

impl OwnedChildren {
    fn register(&self, child: Child) -> Result<(), String> {
        // Recover a poisoned mutex rather than dropping ownership of a live
        // child. The registry contains only Child handles created by Atlas.
        let mut children = self
            .children
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        children.push(child);
        Ok(())
    }

    /// Serializes startup and rolls back every child started by this attempt if
    /// any later prerequisite, readiness check, or identity check fails.
    pub async fn start(&self) -> Result<String, String> {
        let _start_guard = self.start_lock.lock().await;
        self.stop_requested.store(false, Ordering::Release);

        let result = self.start_inner().await;
        if result.is_err() {
            // Startup failure must not leave llama-swap or the API orphaned.
            self.stop();
        }
        result
    }

    async fn start_inner(&self) -> Result<String, String> {
        let root = project_root();
        let settings_path = root.join("settings.json");
        let settings: Value = serde_json::from_slice(
            &tokio::fs::read(&settings_path)
                .await
                .map_err(|e| format!("Cannot read {}: {e}", settings_path.display()))?,
        )
        .map_err(|e| format!("Invalid settings.json: {e}"))?;

        let upstream = settings
            .get("upstream_port")
            .and_then(Value::as_u64)
            .unwrap_or(8080) as u16;
        let api = settings
            .get("server_port")
            .and_then(Value::as_u64)
            .unwrap_or(8090) as u16;

        ensure_not_stopping(&self.stop_requested)?;

        if !port_ready(upstream) {
            let exe = settings
                .get("llama_swap_exe")
                .and_then(Value::as_str)
                .ok_or("settings.json missing llama_swap_exe")?;
            let config = settings
                .get("llama_swap_config")
                .and_then(Value::as_str)
                .ok_or("settings.json missing llama_swap_config")?;
            if !Path::new(exe).is_file() {
                return Err(format!("llama-swap executable not found: {exe}"));
            }
            if !Path::new(config).is_file() {
                return Err(format!("llama-swap config not found: {config}"));
            }

            let stdout = log_file(&root, "llama-swap.log")?;
            let stderr = stdout.try_clone().map_err(|e| e.to_string())?;
            let mut command = Command::new(exe);
            command.arg("--config")
                .arg(config)
                .arg("--listen")
                .arg(format!("127.0.0.1:{upstream}"))
                .current_dir(Path::new(exe).parent().unwrap_or(&root))
                .stdin(Stdio::null())
                .stdout(Stdio::from(stdout))
                .stderr(Stdio::from(stderr));
            hide_console_window(&mut command);
            let child = command.spawn()
                .map_err(|e| format!("Could not start llama-swap: {e}"))?;
            self.register(child)?;
            wait_http(
                &format!("http://127.0.0.1:{upstream}/v1/models"),
                60,
                &self.stop_requested,
            )
            .await?;
        }

        ensure_not_stopping(&self.stop_requested)?;

        if !port_ready(api) {
            let script = root.join("server.py");
            if !script.is_file() {
                return Err(format!("Atlas server.py missing: {}", script.display()));
            }
            self.register(spawn_python(&root, &script)?)?;
            wait_http(
                &format!("http://127.0.0.1:{api}/api/health"),
                20,
                &self.stop_requested,
            )
            .await?;
        }

        ensure_not_stopping(&self.stop_requested)?;

        let client = reqwest::Client::builder()
            .timeout(Duration::from_secs(3))
            .build()
            .map_err(|e| e.to_string())?;
        let health = client
            .get(format!("http://127.0.0.1:{api}/api/health"))
            .send()
            .await
            .map_err(|e| format!("Atlas API health check failed on port {api}: {e}"))?;
        if !health.status().is_success() {
            return Err(format!(
                "Port {api} is occupied by a service that did not pass Atlas health verification"
            ));
        }
        let identity: Value = health
            .json()
            .await
            .map_err(|e| format!("Atlas health response was not valid JSON: {e}"))?;
        if identity.get("server_port").and_then(Value::as_u64) != Some(api as u64)
            || identity.get("upstream_port").and_then(Value::as_u64) != Some(upstream as u64)
        {
            return Err(format!(
                "Port {api} is occupied by an Atlas API with unexpected configuration; expected server {api} and upstream {upstream}."
            ));
        }

        ensure_not_stopping(&self.stop_requested)?;
        Ok(format!(
            "Atlas services ready. API :{api}; llama-swap :{upstream}. Only child processes started by this desktop instance are owned by its supervisor."
        ))
    }

    /// Stops only processes retained in this instance's child registry.
    /// This is synchronous and does not silently skip shutdown because another
    /// async startup task happens to hold a Tokio mutex.
    pub fn stop(&self) {
        self.stop_requested.store(true, Ordering::Release);
        // Recover the registry even if a previous panic poisoned the mutex;
        // skipping cleanup would violate the owned-process lifecycle contract.
        let mut children = self
            .children
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);

        for child in children.iter_mut().rev() {
            if child.try_wait().ok().flatten().is_none() {
                let _ = child.kill();
            }
            let _ = child.wait();
        }
        children.clear();
    }
}
